import React from "react";

const Contact = () => {
  return (
    <div>
      <h1>
        Aqui podrá van a ir los contactos necesarios para que se pueda comunicar
        con nostros.
      </h1>
      <h2>
        Asi que mientras seguimos trabajando en ello, a contunuacion le dejamos
        un juego para que no se aburra
      </h2>

      <iframe
        width="500px"
        height="500px"
        src="https://www.minijuegos.com/embed/hover-skirt"
      ></iframe>
    </div>
  );
};

export default Contact;
